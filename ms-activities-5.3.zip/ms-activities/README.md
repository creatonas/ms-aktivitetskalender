# Aktivitetskalender

WordPress-plugin for aktiviteter med liste, månedsoversikt og kombinert visning. Advanced Custom Fields brukes til redigering av aktivitetsdata.

## Shortcodes

- `[ms_activities]` viser kommende aktiviteter som liste.
- `[ms_calendar]` viser aktiviteter i en månedsoversikt.
- `[ms_activities_toggle]` viser en tilgjengelig bryter mellom liste og måned.

## Oppgradering fra 5.2

Versjon 5.3 beholder posttypen `aktiviteter`, alle shortcode-navn og ACF-feltene `date_from`, `date_to`, `status`, `link` og `activity_info`. Ingen datamigrering er nødvendig.

## Endringer i 5.3

- CSS og JavaScript er flyttet til egne, betinget lastede filer.
- AJAX-parametere valideres og begrenses.
- Ugyldige datoer og statuser håndteres kontrollert.
- Kalenderen henter bare aktiviteter som kan overlappe valgt måned.
- Modal, kalendernavigasjon og visningsbryter har forbedret tastatur- og skjermleserstøtte.
- Frontend kan lese lagrede felt uten fatal feil dersom ACF midlertidig mangler.
- Arrangementlenken vises som knapp i modalvinduet.

Aktivitetspostene slettes ikke ved deaktivering eller avinstallering.
